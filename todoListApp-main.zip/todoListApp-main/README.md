# TO DO List App
This is the code of a Todo list App realized using React Native and Expo.
Please feel free to use this code either for educational purposes or for your own projects